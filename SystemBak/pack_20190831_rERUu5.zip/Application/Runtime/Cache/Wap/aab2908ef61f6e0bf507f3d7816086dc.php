<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改会员</title>
    <link rel="shortcut icon" href="favicon.ico"> <link href="/Public/Default/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="/Public/Default/css/font-awesome.min.css?v=4.4.0" rel="stylesheet">
    <link href="/Public/Default/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="/Public/Default/css/animate.min.css" rel="stylesheet">
    <link href="/Public/Default/css/style.min.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5><a style="color:#00bb9c;margin-right:5px;" href="/Wap/Users/updateuser/uId/<?php echo ($rs_users["uId"]); ?>">修改我的资料</a><small><a style="color:#ff0000" href="/Wap/Users/updateuserloginpassword/uId/<?php echo ($rs_users["uId"]); ?>">修改登陆密码</a></small> </h5>
                        <div class="ibox-tools">
                        </div>
                    </div>
                    <div class="ibox-content">
                        <form method="post" action="/Wap/Users/UpdateUserAction/uId/<?php echo ($rs_users["uId"]); ?>" class="form-horizontal" id="form-admin-add" enctype="multipart/form-data">
                                
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">我的账户</label>
                                        <div class="col-sm-10">
                                        <input type="text" value="<?php echo ($rs_users["uUser"]); ?>" class="form-control" disabled>
                                        </div>
                                    </div>

                                 <div class="form-group">
                                <label class="col-sm-2 control-label">手机号码</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="uTel" value="<?php echo ($rs_users["uTel"]); ?>" id="uTel" placeholder="请输入你的11位手机号码" class="form-control" disabled>
                                    </div>
                                 </div>

                                 <div class="form-group">
                                <label class="col-sm-2 control-label">真实姓名</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="uName" value="<?php echo ($rs_users["uName"]); ?>" id="uName" placeholder="请输入你的真实姓名" class="form-control" disabled>
                                    </div>
                                 </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">银行名称</label>
                                <div class="col-sm-10">
                                    <input type="text" name="yinhangName" value="<?php echo ($rs_users["yinhangName"]); ?>" id="yinhangName" placeholder="请输入你的真实姓名" class="form-control" disabled>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">银行卡号</label>
                                <div class="col-sm-10">
                                    <input type="text" name="yinhangNubmer" value="<?php echo ($rs_users["yinhangNubmer"]); ?>" id="yinhangNubmer" placeholder="请输入你的支付宝账户" class="form-control" disabled>
                                </div>
                            </div>
                                 <div class="form-group">
                                <label class="col-sm-2 control-label">支付宝账户</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="uZhifubao" value="<?php echo ($rs_users["uZhifubao"]); ?>" id="uZhifubao" placeholder="请输入你的支付宝账户" class="form-control" disabled>
                                    </div>
                                 </div>

                                <div class="form-group">
                                <label class="col-sm-2 control-label">性别</label>

                                    <div class="col-sm-10">
                                        <?php if($rs_users["uSex"] == 1): ?><label class="checkbox-inline">
                                                <input type="radio" value="1" name="uSex" checked disabled> 男
                                            </label>
                                            <label class="checkbox-inline">
                                                <input type="radio" value="2" name="uSex" disabled> 女
                                            </label>
                                        <?php else: ?>
                                            <label class="checkbox-inline">
                                                <input type="radio" value="1" name="uSex" disabled> 男
                                            </label>
                                            <label class="checkbox-inline">
                                                <input type="radio" value="2" name="uSex" checked disabled> 女
                                            </label><?php endif; ?>     
                                    </div>
                                </div>

                                 <div class="form-group">
                                <label class="col-sm-2 control-label">电子邮箱</label>
                                    <div class="col-sm-10">
                                        <input type="email" name="uEmail" value="<?php echo ($rs_users["uEmail"]); ?>" id="uEmail" placeholder="非必填项，可留空" class="form-control">
                                    </div>
                                 </div>
                                <?php if($rs_users["uImages"] != null): ?><div class="form-group">
                                <label class="col-sm-2 control-label">原头像</label>
                                    <div class="col-sm-10">
                                        <img src="/<?php echo ($rs_users["uImages"]); ?>" width="150px;" height="150px;">
                                    </div>
                                 </div><?php endif; ?>

                                 <div class="form-group">
                                <label class="col-sm-2 control-label"> <?php if($rs_users["uImages"] != null): ?>上传<?php else: ?>新<?php endif; ?>头像</label>
                                    <div class="col-sm-10">
                                        <input type="file" name="uImages" class="form-control">
                                    </div>
                                 </div>

                                 <div class="form-group">
                                <label class="col-sm-2 control-label">请输入安全密码</label>
                                    <div class="col-sm-10">
                                        <input type="password" name="uZfPwd" id="uZfPwd" placeholder="输入安全码才能修改" class="form-control">
                                    </div>
                                 </div>
                                
                            <div class="hr-line-dashed"></div>
                            <div class="form-group" style="margin-top:-30px;">
                                <label class="col-sm-2 control-label"></label>
                                    <div class="col-sm-10">
                                        <span style="color:#ff0000; font-weight:bold">温馨提示:部分重要资料如需修改请给平台留言</span>
                                    </div>
                                 </div>
                                
                            <div class="hr-line-dashed" style="margin-top:-10px;"></div>
                            <!--
                            <div class="form-group">
                                <div class="col-sm-4 col-sm-offset-2">
                                    <button class="btn btn-primary" type="submit">修改会员</button>
                                   
                                </div>
                            </div>
                            -->
                            
                            <div class="form-group">
                                <div class="col-sm-8 col-sm-offset-2">
                                    <input class="btn btn-primary" type="submit" value="修改会员">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="/Public/Default/js/jquery.min.js?v=2.1.4"></script>
    <script src="/Public/Default/js/bootstrap.min.js?v=3.3.6"></script>
    <script src="/Public/Default/js/content.min.js?v=1.0.0"></script>
    <script src="/Public/Default/js/plugins/iCheck/icheck.min.js"></script>

<script type="text/javascript" src="/Public/Default/check/js/jquery.validate.min.js"></script> 

<script type="text/javascript" src="/Public/Default/check/js/messages_zh.min.js"></script> 



<script type="text/javascript" src="/Public/Default/check/js/validate-methods.js"></script> 



   
    <script>
        $(document).ready(function(){$(".i-checks").iCheck({checkboxClass:"icheckbox_square-green",radioClass:"iradio_square-green",})});
    </script>
    
    <script type="text/javascript">
	$(function(){
	$("#form-admin-add").validate({
		rules:{
			uUser:{
				required:true,
                minlength:2,
                maxlength:20
			},
            uName:{
                required:true,
                minlength:2,
                maxlength:8

            },
            uSfId:{
                required:true,
                minlength:15,
                maxlength:18

            },
            uTel:{
                required:true,
                isPhone:true,

            },
            uWeixin:{
                required:true,

            },
            uZhifubao:{
                required:true,

            },
            uZfPwd:{
                required:true,
                minlength:6,
                maxlength:6

            },

		},
		onkeyup:false,
		focusCleanup:true,
		success:"valid",
		submitHandler:function(form){
			$(form).ajaxSubmit();
			var index = parent.layer.getFrameIndex(window.name);
			parent.$('.btn-refresh').click();
			parent.layer.close(index);
		}
	});
});
</script>

    <script>
        var $parentNode = window.parent.document;
        if ($(".tooltip-demo").tooltip({
            selector: "[data-toggle=tooltip]",
            container: "body"
        }), $(".modal").appendTo("body"), $("[data-toggle=popover]").popover(), $(".collapse-link").click(function() {
            var o = $(this).closest("div.ibox"),
                e = $(this).find("i"),
                i = o.find("div.ibox-content");
            i.slideToggle(200),
                e.toggleClass("fa-chevron-up").toggleClass("fa-chevron-down"),
                o.toggleClass("").toggleClass("border-bottom"),
                setTimeout(function() {
                        o.resize(),
                            o.find("[id^=map-]").resize()
                    },
                    50)
        }), $(".close-link").click(function() {
            var o = $(this).closest("div.ibox");
            o.remove()
        }), top == this) {
            //update lishibo by 20190308
            var gohome = '<div class="gohome"><a class="animated bounceInUp" href="http://huimingou2019.com/wap/index" title="返回首页"><i class="fa fa-home"></i></a></div>';
            $("body").append(gohome)
        }
    </script>
    
</body>

</html>