<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php echo ($rs_systemName["sName"]); ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=0,minimum-scale=0.5">
	<link rel="shortcut icon" href="/favicon.ico">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">


	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/js/suimobile/sm.min.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/js/suimobile/sm-extend.min.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/public.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/init.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/deal.css";	/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/css3-3d-circle-progress.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/datepicker.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/lynn.css";    />
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/doexchange.css";	/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/integral_mall.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/goods_exchange.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/goods_information.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/uc_learn.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/licai_deal_detail.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/datepicker.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/lynn.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/Log_recharge.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/deal_mobile.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/Repayment.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/Statistics.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/cart_index.css";	/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/youhui_comment_list.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/user_addr_list.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/pay_order_index.css";	/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/search.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/uc_add_bank.css";	/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/uc_bank.css";	/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/uc_to_transfer.css	";	/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/uc_carry_money_log.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/uc_save_carry.css";	/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/uc_center.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/uc_collect.css	";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/uc_incharge.css";	/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/uc_voucher.css";	/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/uc_money_log.css";	/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/uc_quick_refund.css";	/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/uc_account_log.css";	/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/login.css";	/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/uc_collect.css";/>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/uc_transfer.css";/>


	<script type='text/javascript' src='/Public/Default/wap/js/suimobile/zepto.min.js' charset='utf-8'></script>
	<script type='text/javascript' src='/Public/Default/wap/js/fastclick.js' charset='utf-8'></script>
	<link rel="stylesheet" type="text/css" href="/Public/Default/wap/css/font-awesome-4.2.0/css/font-awesome.min.css" />

	<script type="text/javascript">
        var APP_ROOT = '<?php echo ($APP_ROOT); ?>';
        var WAP_PATH = '<?php echo ($WAP_ROOT); ?>';
        var APP_ROOT_ORA = '<?php echo ($PC_URL); ?>';
        var SITE_DOMAIN = "<?php echo ($data["site_domain"]); ?>";
        //var isapp = "<{function name="intval" f="$smarty.request.app"}>";
        var isapp = "1";
        //var __HASH_KEY__ = "<{insert name="get_hash_key"}>";
        $.config = {
            swipePanelOnlyClose: true
        }

        if ('addEventListener' in document) {
            document.addEventListener('DOMContentLoaded', function() {
                FastClick.attach(document.body);
            }, false);
        }
	</script>
</head>

<body>

<script type='text/javascript' src='//g.alicdn.com/sj/lib/zepto/zepto.min.js' charset='utf-8'></script>
<script type='text/javascript' src='//g.alicdn.com/msui/sm/0.6.2/js/sm.min.js' charset='utf-8'></script>
<script type='text/javascript' src='//g.alicdn.com/msui/sm/0.6.2/js/??sm.min.js,sm-extend.min.js' charset='utf-8'></script>
<header class="bar bar-nav">
    <a class="icon  pull-left" id="zuo" href="/wap">返回</a>
    <a class="icon  pull-right" id="you" href="">刷新</a>
    <h1 class="title">交易区</h1>
</header>
<style>
    #zuo {
        color: #00FF00;
        font-size: 15px;
    }
    #you {
        color: #00FF00;
        font-size: 15px;
    }
</style>
<div class="content">
    <div class="buttons-tab">
        <a href="/Wap/Assistance/index/uId/<?php echo ($uIdjs); ?>" class="  button">优选区</a>
        <a href="/Wap/Assistance/SuiJiQu/uId/<?php echo ($uIdjs); ?>" class="  button">随机区</a>
        <a href="/Wap/Assistance/ZiXuanQu/uId/<?php echo ($uIdjs); ?>" class=" active button">自选区</a>
    </div>
    <div class="content-block">
        <div class="tabs">



            <div  >
                <div class="content-block">



                    <div class="card">
                        <div class="card-header">自选区</div>
                        <div class="card-content">

                            <form method="post" action="/Wap/Assistance/ziXuanQuTj/ceshi/<?php echo ($ceshi); ?>/biaojige<?php echo ($biaojige); ?>" id="form-admin-add" >
                                <div class="content-padded grid-demo">
                                    <div class="row" style="margin:0px;">
                                        <div class="col-30">请输入账号:</div>
                                        <div class="col-70">
                                            <input style="width: 100%;height: 32px;margin-left:1rem;   border:1px solid #469987; " type="text" name="uiUJiner"   placeholder="今天您还可以搜索<?php echo ($haisheng); ?>次" id="uiUJiner" >
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-100"><button class="button   button-success" type="submit">搜索</button></div>
                                    </div>
                                </div>
                            </form>

                        </div>
                        <div class="card-footer"><span style="color:#ff0000; font-weight:bold">距下次可交割倒计时(小时)：<?php echo ($shifouke); ?></span></div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>