<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>分享链接注册下级会员</title>
    <link rel="shortcut icon" href="favicon.ico"> <link href="/Public/Default/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="/Public/Default/css/font-awesome.min.css?v=4.4.0" rel="stylesheet">
    <link href="/Public/Default/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="/Public/Default/css/animate.min.css" rel="stylesheet">
    <link href="/Public/Default/css/style.min.css?v=4.1.0" rel="stylesheet">

</head>
<style type="text/css">
    input[type="button"], input[type="submit"], input[type="reset"] {
        -webkit-appearance: none;
    }
</style>
<body class="gray-bg">

<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-sm-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5><a style="color:#00bb9c;margin-right:5px;" href="#">注册下级会员链接</a> <small></small></h5>
                    <div class="ibox-tools">

                    </div>
                </div>
                <div class="ibox-content">

                        <div class="form-group">

                            <div class="col-sm-10">
                                <textarea rows="2" name="S1" cols="20" value="<?php echo ($fenlian); ?>" class="form-control" readonly="readonly" id="fuzhi"><?php echo ($fenlian); ?></textarea>
                            </div>
                        </div>

                        <div class="hr-line-dashed"></div>
                        <button onclick="copyTexts()">复制链接</button>

                        <div class="form-group">
                            <div class="col-sm-8 col-sm-offset-2">

                            </div>
                        </div>

                </div>
            </div>
        </div>
    </div>

    <script src="/Public/Default/js/jquery.min.js?v=2.1.4"></script>
    <script src="/Public/Default/js/bootstrap.min.js?v=3.3.6"></script>
    <script src="/Public/Default/js/content.min.js?v=1.0.0"></script>
    <script src="/Public/Default/js/plugins/iCheck/icheck.min.js"></script>
    <script>
        function copyTexts() {
            var input = document.getElementById("fuzhi");
            input.select(); // 选中文本
            document.execCommand("copy"); // 执行浏览器复制命令
            alert("复制成功");
        }
    </script>

</body>

</html>