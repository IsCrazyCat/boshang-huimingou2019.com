<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>查看我的付款凭证</title>
    

    <link rel="shortcut icon" href="favicon.ico"> <link href="/Public/Default/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="/Public/Default/css/font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <link href="/Public/Default/css/animate.min.css" rel="stylesheet">
    <link href="/Public/Default/css/style.min.css?v=4.1.0" rel="stylesheet">

</head>
<script src="/Public/Default/js/echarts.js"></script>
<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5><a href="/Wap/Assistance/wantinvestlists/uId/<?php echo ($rs_invest["uiUid"]); ?>" style="color:#00bb9c;">查看我的付款凭证</a></h5>
                        <div class="ibox-tools">
                        </div>
                    </div>
                    <div class="ibox-content" style="height: 700px;">
                    <?php if($rs_invest["uiImages"] == null): ?><a href="/Wap/Assistance/wantinvestlists/uId/<?php echo ($rs_invest["uiUid"]); ?>"><img src="/Public/Default/img/fukuan.png"></a>
                    <?php else: ?>
                    <a href="/Wap/Assistance/wantinvestlists/uId/<?php echo ($rs_invest["uiUid"]); ?>"><img src="/<?php echo ($rs_invest["uiImages"]); ?>"></a><?php endif; ?>
                        <div class="flot-chart">
    <div id="main1" style="width: 100%;height:600px;"></div>
                
                            <div class="flot-chart-content" id="flot-pie-chart">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="/Public/Default/js/jquery.min.js?v=2.1.4"></script>
    <script src="/Public/Default/js/bootstrap.min.js?v=3.3.6"></script>
    <script src="/Public/Default/js/plugins/flot/jquery.flot.js"></script>
    <script src="/Public/Default/js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="/Public/Default/js/plugins/flot/jquery.flot.resize.js"></script>
    <script src="/Public/Default/js/plugins/flot/jquery.flot.pie.js"></script>
    <script src="/Public/Default/js/content.min.js?v=1.0.0"></script>
    <script src="/Public/Default/js/demo/flot-demo.min.js"></script>
    
</body>

</html>