<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>公告详情</title>
    <link rel="shortcut icon" href="favicon.ico"> <link href="/Public/Default/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="/Public/Default/css/font-awesome.min.css?v=4.4.0" rel="stylesheet">
    <link href="/Public/Default/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="/Public/Default/css/animate.min.css" rel="stylesheet">
    <link href="/Public/Default/css/style.min.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5><span style="color:#00bb9c;margin-right:5px;">公告详情</span> <small><a style="color:#ff0000" href="/Wap/Announcement/lists"> 公告列表</a></small></h5>
                        <div class="ibox-tools">
                            
                        </div>
                    </div>
                    <div class="ibox-content">
                        <form method="post" action="/Wap/Announcement/UpdateAction/annId/<?php echo ($rs_announcement["annId"]); ?>" class="form-horizontal" id="form-admin-add" >
                            <div class="form-group">
                                <label class="col-sm-2 control-label">标记</label>
                                <div class="col-sm-10" style="margin-top: 7px">
                                    <?php echo ($rs_announcement["annNum"]); ?>
                                </div>
                            </div>
                            
                                <div class="form-group">
                                <label class="col-sm-2 control-label">标题</label>
                                    <div class="col-sm-10" style="margin-top: 7px">
                                        <?php echo ($rs_announcement["annTitle"]); ?>
                                    </div>
                            	</div>
                            
                            
                                <div class="form-group">
                                <label class="col-sm-2 control-label">内容</label>
                                    <div class="col-sm-10" style="margin-top: 7px">
                                    <?php echo ($rs_announcement["annContent"]); ?>
                                       
                                    </div>
                            	</div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="/Public/Default/js/jquery.min.js?v=2.1.4"></script>
    <script src="/Public/Default/js/bootstrap.min.js?v=3.3.6"></script>
    <script src="/Public/Default/js/content.min.js?v=1.0.0"></script>
    <script src="/Public/Default/js/plugins/iCheck/icheck.min.js"></script>

<script type="text/javascript" src="/Public/Default/check/js/jquery.validate.min.js"></script> 

<script type="text/javascript" src="/Public/Default/check/js/messages_zh.min.js"></script> 



<script type="text/javascript" src="/Public/Default/check/js/validate-methods.js"></script> 



   
    <script>
        $(document).ready(function(){$(".i-checks").iCheck({checkboxClass:"icheckbox_square-green",radioClass:"iradio_square-green",})});
    </script>
    
    <script type="text/javascript">
	$(function(){
	$("#form-admin-add").validate({
		rules:{
			annNum:{
				required:true,
			},
			annTitle:{
				required:true,
				minlength:5,
				maxlength:30
			},
			annContent:{
				required:true,
                minlength:20,
                maxlength:6000
			}
		},
		onkeyup:false,
		focusCleanup:true,
		success:"valid",
		submitHandler:function(form){
			$(form).ajaxSubmit();
			var index = parent.layer.getFrameIndex(window.name);
			parent.$('.btn-refresh').click();
			parent.layer.close(index);
		}
	});
});
</script> 
    
    
</body>

</html>