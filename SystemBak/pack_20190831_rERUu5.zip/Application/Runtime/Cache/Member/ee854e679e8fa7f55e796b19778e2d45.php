<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>自选区</title>
    <link rel="shortcut icon" href="favicon.ico"> <link href="/Public/Default/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="/Public/Default/css/font-awesome.min.css?v=4.4.0" rel="stylesheet">
    <link href="/Public/Default/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="/Public/Default/css/animate.min.css" rel="stylesheet">
    <link href="/Public/Default/css/style.min.css?v=4.1.0" rel="stylesheet">
    <link href="/Public/Default/dist/wan-spinner.css" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5><a style="color:#00bb9c; margin-right:5px;" href="#">自选区</a> <small></small></h5>
                        <div class="ibox-tools">
                            
                        </div>
                    </div>
                    <div class="ibox-content">
                            <div class="form-group" style="margin-top:-30px;">
                                <label class="col-sm-2 control-label"></label>
                                    <div class="col-sm-10">
                                        <span style="color:#ff0000; font-weight:bold">距下次可交割倒计时(小时)：<?php echo ($shifouke); ?></span>
                                    </div>
                                 </div>
                        <form method="post" action="/Member/Assistance/ziXuanQuTj/ceshi/<?php echo ($ceshi); ?>/biaojige<?php echo ($biaojige); ?>" class="form-horizontal" id="form-admin-add" >
                      
                                <div class="form-group">
                                <label class="col-sm-2 control-label">请输入账号:</label>
                                    <div class="col-sm-10 wan-spinner-1">
    <input style="width: 100%;height: 32px; margin-left:0px; margin-right:10px; text-align: left; border:1px solid #469987; padding-left:14px;" type="text" name="uiUJiner"   placeholder="今天您还可以搜索<?php echo ($haisheng); ?>次" id="uiUJiner" >
                                    </div>
                            	</div>
                            <div class="hr-line-dashed" style="margin-top:-10px;"></div>
                            <div class="form-group">
                                <div class="col-sm-4 col-sm-offset-2">
                                        <button class="btn btn-primary" type="submit">搜索</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="/Public/Default/js/jquery.min.js?v=2.1.4"></script>
    <script src="/Public/Default/js/bootstrap.min.js?v=3.3.6"></script>
    <script src="/Public/Default/js/content.min.js?v=1.0.0"></script>
    <script src="/Public/Default/js/plugins/iCheck/icheck.min.js"></script>
<script type="text/javascript" src="/Public/Default/check/js/jquery.validate.min.js"></script> 
<script type="text/javascript" src="/Public/Default/check/js/messages_zh.min.js"></script> 
<script type="text/javascript" src="/Public/Default/check/js/validate-methods.js"></script> 
    <script>
        $(document).ready(function(){$(".i-checks").iCheck({checkboxClass:"icheckbox_square-green",radioClass:"iradio_square-green",})});
    </script>
    <script type="text/javascript">
	$(function(){
	$("#form-admin-add").validate({
		rules:{
			uiUJiner:{
				required:true,
			},
           uZfPwd:{
                required:true,
                minlength:6,
                maxlength:6

            },
		},
		onkeyup:false,
		focusCleanup:true,
		success:"valid",
		submitHandler:function(form){
			$(form).ajaxSubmit();
			var index = parent.layer.getFrameIndex(window.name);
			parent.$('.btn-refresh').click();
			parent.layer.close(index);
		}
	});
});
</script> 
  
  <script src="/Public/Default/dist/wan-spinner.js"></script> 
  <script>
  $(document).ready(function() {
    var options = {
      maxValue: <?php echo ($paramenters["upMaxMoney"]); ?>,
      minValue: <?php echo ($paramenters["upTZMultiples"]); ?>,
      step: <?php echo ($paramenters["upTZMultiples"]); ?>,
      inputWidth: 150,
      start: 0,
      plusClick: function(val) {
        console.log(val);
      },
      minusClick: function(val) {
        console.log(val);
      },
      exceptionFun: function(val) {
        console.log("excep: " + val);
      },
      valueChanged: function(val) {
        console.log('change: ' + val);
      }
    }
    $(".wan-spinner-1").WanSpinner(options);

  });
  </script>   
    
</body>

</html>