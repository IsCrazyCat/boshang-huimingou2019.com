<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>手续费列表</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="/Public/Default/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="/Public/Default/css/font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <!-- Data Tables -->
    <link href="/Public/Default/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">

    <link href="/Public/Default/css/animate.min.css" rel="stylesheet">
    <link href="/Public/Default/css/style.min.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5><a style="color:#00bb9c;margin-right:5px;" href="/Member/RegCode/regcodelists/st/2">手续费列表</a> <small><a style="color:#ff0000" href="/Member/RegCode/applicationregcode/uId/<?php echo ($uId); ?>">购买手续费</a></small></h5>
                        <div class="ibox-tools">
                           
                        </div>
                    </div>
                    <div class="ibox-content">
                        <table class="table table-striped table-bordered table-hover">
                            <thead>
                                <tr><!--
                                    <th class="dropdown hidden-xs">ID</th>-->
                                    <th>手续费</th>
                                    <th class="dropdown hidden-xs">购买账号</th>
                                    <th class="dropdown hidden-xs">购买时间</th>
                                    <th class="dropdown hidden-xs">售价</th>
                                    <th class="dropdown hidden-xs">优惠金额</th>
                                    <th class="dropdown hidden-xs">实付金额</th>
                                    <th class="dropdown hidden-xs">购买类型</th>
                                    <th >状态</th>
                                    <th class="dropdown hidden-xs">使用账号</th>
                                    <th class="dropdown hidden-xs">使用时间</th>

                                </tr>
                            </thead>
                            <tbody>
                            <?php if(is_array($rs_mregcodes)): $i = 0; $__LIST__ = $rs_mregcodes;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val_mregcodes): $mod = ($i % 2 );++$i;?><tr class="gradeX">
                                <!--
                                    <td class="dropdown hidden-xs"><?php echo ($val_mregcodes["mrcId"]); ?></td>
                                -->
                                    <td><?php echo ($val_mregcodes["mrcRegCode"]); ?></td>
                                <?php $muId=$val_mregcodes["mrcMUid"]; $usersm=M("users"); $rs_usersm=$usersm->where("uId={$muId}")->field("uUser")->find(); $usermInfo=$rs_usersm["uUser"]; ?>
                                    <td class="dropdown hidden-xs"><?php echo ($usermInfo); ?></td>
                                    <td class="dropdown hidden-xs"><?php echo ($val_mregcodes["mrcStartDate"]); ?></td>
                                    <td class="dropdown hidden-xs">￥ <?php echo ($val_mregcodes["mrcPrice"]); ?> 元</td>
                                    <td class="dropdown hidden-xs">￥ <?php echo ($val_mregcodes["mrcHuiPrice"]); ?> 元</td>
                                    <td class="dropdown hidden-xs">￥ <?php echo ($val_mregcodes["mrcPayPrice"]); ?> 元</td>
                                <?php if($val_mregcodes["mrcMorZ"] == 0): ?><td class="dropdown hidden-xs"><button type="button" class="btn btn-primary btn-xs">免费赠送</button></td>
                                <?php elseif($val_mregcodes["mrcMorZ"] == 1): ?>
                                    <td class="dropdown hidden-xs"><button type="button" class="btn btn-success btn-xs">全款价格</button></td>
                                <?php elseif($val_mregcodes["mrcMorZ"] == 2): ?>
                                    <td class="dropdown hidden-xs"><button type="button" class="btn btn-info btn-xs">尊享优惠</button></td><?php endif; ?>
                                <?php if($val_mregcodes["mrcState"] == 1): ?><td><button type="button" class="btn btn-default btn-xs">已使用</button></td>
                                <?php else: ?>
                                    <td><button type="button" class="btn btn-primary btn-xs">未使用</button></td><?php endif; ?>
                                 
                                 <?php $uId=$val_mregcodes["mrcUseUid"]; if($val_mregcodes["mrcUseUid"]==0){ $userInfo="暂未使用"; }else{ $users=M("users"); $rs_users=$users->where("uId={$uId}")->field("uUser")->find(); $userInfo=$rs_users["uUser"]; } ?>

                                    <td class="dropdown hidden-xs"><?php echo ($userInfo); ?></td>

                                <?php if(($val_mregcodes["mrcUseDate"] == null) OR ($val_mregcodes["mrcUseDate"] == '0000-00-00 00:00:00')): ?><td class="dropdown hidden-xs">暂未使用</td>
                                <?php else: ?>
                                    <td class="dropdown hidden-xs"><?php echo ($val_mregcodes["mrcUseDate"]); ?></td><?php endif; ?>
                                </tr><?php endforeach; endif; else: echo "" ;endif; ?>    
                            </tbody>
                            
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="/Public/Default/js/jquery.min.js?v=2.1.4"></script>
    <script src="/Public/Default/js/bootstrap.min.js?v=3.3.6"></script>
    <script src="/Public/Default/js/plugins/jeditable/jquery.jeditable.js"></script>
    <script src="/Public/Default/js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="/Public/Default/js/plugins/dataTables/dataTables.bootstrap.js"></script>
    <script src="/Public/Default/js/content.min.js?v=1.0.0"></script>
    <script>
        $(document).ready(function(){$(".dataTables-example").dataTable();var oTable=$("#editable").dataTable();oTable.$("td").editable("../example_ajax.php",{"callback":function(sValue,y){var aPos=oTable.fnGetPosition(this);oTable.fnUpdate(sValue,aPos[0],aPos[1])},"submitdata":function(value,settings){return{"row_id":this.parentNode.getAttribute("id"),"column":oTable.fnGetPosition(this)[2]}},"width":"90%","height":"100%"})});function fnClickAddRow(){$("#editable").dataTable().fnAddData(["Custom row","New row","New row","New row","New row"])};
    </script>

</body>

</html>