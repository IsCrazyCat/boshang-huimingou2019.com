<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>会员中心首页</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="/Public/Default/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="/Public/Default/css/font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <!-- Morris -->
    <link href="/Public/Default/css/plugins/morris/morris-0.4.3.min.css" rel="stylesheet">

    <!-- Gritter -->
    <link href="/Public/Default/js/plugins/gritter/jquery.gritter.css" rel="stylesheet">

    <link href="/Public/Default/css/animate.min.css" rel="stylesheet">
    <link href="/Public/Default/css/style.min.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content">


        <div class="row">

        <div class="col-sm-12">
                <div>
                    <table class="table">
                        <tbody>
                            <tr>
                                <td>
                                <?php if($benjin < 0): endif; ?>
                                    <button type="button" class="btn btn m-r-sm" style="width: 100%; background-color: #d87570; color: #ffffff"><strong style="font-size: 16px;">本 金</strong><br><strong style="font-size: 18px;">&yen; <?php if($benjin < 0): ?><span style="color: #00ff00"><?php echo ($benjin); ?> </span><?php else: echo ($benjin); endif; ?>元</strong></button>
                                    
                                </td>
                                <td>
                                    <button type="button" class="btn btn m-r-sm" style="width: 100%; background-color: #f9ad59; color: #ffffff"><strong style="font-size: 16px;">奖 金</strong><br><strong style="font-size: 18px;">&yen; <?php echo ($zongjiangjin); ?> 元</strong></button>
                                    
                                </td>
                                
                            </tr>

                            <tr>
                            <td>
                                    <button type="button" class="btn btn m-r-sm" style="width: 100%; background-color: #a9c7b5; color: #ffffff"><strong style="font-size: 16px; ">利 息</strong><br><strong style="font-size: 18px;">&yen; <?php echo ($zonglixi); ?> 元</strong></button>
                                    
                                </td>
                                <td>
                                    <button type="button" class="btn btn m-r-sm" style="width: 100%; background-color: #c5adca; color: #ffffff"><strong style="font-size: 16px;">可提本金</strong><br><strong style="font-size: 18px;">&yen; <?php echo ($rs_tixianbenjin); ?> 元</strong></button>
                                    
                                </td>

                            </tr>
                        </tbody>
                    </table>
                </div>
        <?php if($qiandaostates == 1): ?><div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title panel" style="color: #fe6b91" >
                    <?php if($countlog == 0): ?><button type="button" class="btn-rounded" style="background: #fe6b91; height: 30px;" ><a style="color:#ffffff; font-weight: bold;" href="/Member/Index/UserSign/uId/<?php echo ($uId); ?>">每日签到</a></button>
                    <?php else: ?>
                        <button type="button" class="btn-rounded" style="background: #c3c3c3; height: 30px;" ><a style="color:#ffffff; font-weight: bold;" >今日已签到</a></button><?php endif; ?>
                        
                        <span style="margin-left:10px"><?php echo ($html); ?></span>
                    </div>
                </div>
            </div>
        </div><?php endif; ?>
    
        <div class="row">
            <div class="col-sm-4">
                <div class="ibox float-e-margins">
                    <div class="ibox-title panel panel-danger" >
                        <button type="button" class="btn btn-w-m btn-danger"><a style="color:#ffffff; font-weight: bold; margin-right: 10px;" href="/Announcement/lists">重要公告</a></button>
                        <div class="ibox-tools">
                            <a style="color:#ed5264; font-weight: bold;" href="/Announcement/lists">更多</a>
                        </div>
                    </div>

                    <div class="ibox-content">
                        <div class="feed-activity-list">
							<?php if(is_array($rs_announcement)): $i = 0; $__LIST__ = array_slice($rs_announcement,0,1,true);if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val_announcement): $mod = ($i % 2 );++$i;?><div class="feed-element">
                                <div>
                                    <small class="pull-right text-navy"><?php echo ($val_announcement["annDate"]); ?></small>
                                    <span class="label label-danger pull-left" ><?php echo ($val_announcement["annNum"]); ?> </span> &nbsp;<strong><a href="/Announcement/show/annId/<?php echo ($val_announcement["annId"]); ?>"><?php echo (mb_substr($val_announcement["annTitle"],0,28,'utf-8')); ?></a></strong><p>
                                    <div style="text-indent:2em; line-height:24px;}"><?php echo (mb_substr($val_announcement["annContent"],0,400,'utf-8')); ?></div>
                                    <small class="text-muted"></small>
                                </div>
                            </div><?php endforeach; endif; else: echo "" ;endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-8">

                <div class="row">
                
                    <div class="col-sm-6">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title panel panel-info" >
                                <button type="button" class="btn btn-w-m btn-info"><a style="color:#ffffff" href="/Assistance/wantinvest/uId/<?php echo ($uId); ?>">提供援助</a></button>
                                <div class="ibox-tools">
                                <a style="color:#24c8bf" href="/Assistance/wantinvestlists/uId/<?php echo ($uId); ?>">更多</a>

                                    
                                </div>
                            </div>
                            <div class="ibox-content">
                                <table class="table table-hover no-margins">
                                    <thead>
                                        <tr>
                                            <th>订单</th>
                                            <!--
                                            <th>日期</th>
                                            -->
                                            <th>金额</th>
                                            <th>交易状态</th>
                                            <th>剩余时间</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php if(is_array($rs_users_invest)): $k = 0; $__LIST__ = $rs_users_invest;if( count($__LIST__)==0 ) : echo "$empty" ;else: foreach($__LIST__ as $key=>$val_users_invest): $mod = ($k % 2 );++$k; $users_parameters=M("users_parameters"); $rs_xiqian=$users_parameters->where("upId=1")->field("upTermOfInvestment,upPaymentPeriod,upCollectionPeriod")->find(); $enddate=strtotime($val_users_invest["uiTouziEndDate"]); $daenddateutuj=date("Y/m/d H:i:s",$enddate); $nowtime=time(); $startqixian=strtotime($val_users_invest["uiSuccessDate"]); $dangqiantime=strtotime($nowtime); $shengyu_qiu=$enddate-$dangqiantime; if($shengyu_qiu < 0){ $days =0; $hours =0; $mins =0; $secs =0; }else{ $days = intval($shengyu_qiu/86400); $remain = $shengyu_qiu%86400; $hours = intval($remain/3600); $remain = $shengyu_qiu%3600; $mins = intval($remain/60); $secs = $remain%60; } $qixian=$enddate-$startqixian; $shengyu=round((($nowtime-$startqixian)/$qixian),2)*100; if($shengyu>100){ $shengyu=100; } $daojishi=round((($enddate-$nowtime)/86400),1); $pipeitime=strtotime($val_users_invest["uiStateDate"]); $maxpaytime=$rs_xiqian["upPaymentPeriod"]*3600; $shengyupay=$nowtime-($pipeitime+$maxpaytime); if($shengyupay>0){ $shengyupay=0; } ?>
                                        <tr>
                                        <?php if($val_users_invest["uiState"] == 0): ?><td><span class="label label-default">排单中</span></td>
                                        <?php elseif($val_users_invest["uiState"] == 1 AND $val_users_invest["uiZhifu"] == 0): ?>
                                        <?php if($shengyupay == 0): ?><td><span class="label label-default"><a style="color: #ffffff" >待支付</a></span></td>

                                        <?php else: ?>
                                            <td><span class="label label-danger"><a style="color: #ffffff" href="/Assistance/yespayinvest/uiId/<?php echo ($val_users_invest["uiId"]); ?>">待支付</a></span></td><?php endif; ?>
                                        <?php elseif($val_users_invest["uiZhifu"] == 1 AND $val_users_invest["uiSuccess"] == 0): ?>
                                            <td><span class="label label-info"><a style="color: #ffffff" href="/Assistance/showunuserinfo/unuserId/<?php echo ($val_users_invest["uiBeijiuyuanUid"]); ?>">待收款</a></span></td>

                                        <?php elseif($val_users_invest["uiSuccess"] == 1 AND $val_users_invest["uiTouziEnd"] == 0): ?>
                                            <td><span class="label label-primary">进行中</span></td>
                                            <!--
                                        <?php elseif($val_users_invest["uiTouziEnd"] == 1): ?>
                                        	<td><span class="label label-success">已完成</span></td>
                                            --><?php endif; ?>
                                        <!--
                                            <td><i class="fa fa-clock-o"></i> <?php echo ($val_users_invest["uiDate"]); ?></td>										
                                        -->
                                        <td><?php echo ($val_users_invest["uiUJiner"]); ?></td>
                                        <?php if($val_users_invest["uiState"] == 0): ?><td style="color:#949492">等待系统匹配中</td>
                                        <td style="color:#949492">0%</td>
                                        <?php elseif($val_users_invest["uiState"] == 1 AND $val_users_invest["uiZhifu"] == 0): ?>
                                        <?php $users_parameters=M("users_parameters"); $rs_xiqian=$users_parameters->where("upId=1")->field("upTermOfInvestment,upPaymentPeriod,upCollectionPeriod")->find(); $maxpaytime=($rs_xiqian["upPaymentPeriod"])*3600; $nowtime=time(); $enddaojishi=$pipeitime+$maxpaytime; $daojiinput=date("Y/m/d H:i:s",$enddaojishi); ?>
                                        <?php if($enddaojishi < $nowtime): ?><td>
                                        系统匹配时间<br> <?php echo ($val_users_invest["uiStateDate"]); ?><br>
                                        <span style="color:#ff0000; font-weight: bold;">我方打款超时</span></td>
                                        <td style="color:#ff0000;">0%</td>

                                        <?php else: ?>
                                                <td >
                                                系统匹配时间<br> <?php echo ($val_users_invest["uiStateDate"]); ?><br>
                                                <span style="color:#ff0000; font-weight: bold;">我方打款还剩<br></span>
                                                <span style="color:#ff0000; font-weight: bold;" id="t_d<?php echo ($k); ?>">00天</span>
                                                <span style="color:#ff0000; font-weight: bold;" id="t_h<?php echo ($k); ?>">00时</span>
                                                <span style="color:#ff0000; font-weight: bold;" id="t_m<?php echo ($k); ?>">00分</span>
                                                <span style="color:#ff0000; font-weight: bold;" id="t_s<?php echo ($k); ?>">00秒</span>
                                                </td>
                                                <td style="color:#ff0000;">0%</td>
                                        
                                            <script>
                                               function GetRTime(){
                                                   var EndTime= new Date('<?php echo ($daojiinput); ?>');
                                                   var NowTime = new Date();
                                                   var t =EndTime.getTime() - NowTime.getTime();
                                                   var d=Math.floor(t/1000/60/60/24);
                                                   var h=Math.floor(t/1000/60/60%24);
                                                   var m=Math.floor(t/1000/60%60);
                                                   var s=Math.floor(t/1000%60);
                                            
                                                   document.getElementById("t_d<?php echo ($k); ?>").innerHTML = d + "天";
                                                   document.getElementById("t_h<?php echo ($k); ?>").innerHTML = h + "时";
                                                   document.getElementById("t_m<?php echo ($k); ?>").innerHTML = m + "分";
                                                   document.getElementById("t_s<?php echo ($k); ?>").innerHTML = s + "秒";
                                               }
                                               setInterval(GetRTime,0);
                                            </script><?php endif; ?>


                                        <?php elseif($val_users_invest["uiZhifu"] == 1 AND $val_users_invest["uiSuccess"] == 0): ?>
                                        
                                        <?php $users_parameters=M("users_parameters"); $rs_xiqianj=$users_parameters->where("upId=1")->field("upTermOfInvestment,upPaymentPeriod,upCollectionPeriod")->find(); $maxyespayuj=$rs_xiqianj["upCollectionPeriod"]*3600; $paytimej=strtotime($val_users_invest["uiZhifuDate"]); $nowtimeuj=time(); $enddaojishiuj=$paytimej+$maxyespayuj; $daojiinputuj=date("Y/m/d H:i:s",$enddaojishiuj); ?>
                                        <?php if($enddaojishiu < $nowtimeu): ?><td>
                                        我方打款时间<br> <?php echo ($val_users_invest["uiZhifuDate"]); ?><br>
                                        <span style="color:#e1790a; font-weight: bold;">对方收款超时</span>
                                        </td>
                                        <td style="color:#e1790a;">0%</td>

                                        <?php else: ?>
                                        <td >
                                                我方打款时间<br> <?php echo ($val_users_invest["uiZhifuDate"]); ?><br>
                                                <span style="color:#06b6b0; font-weight: bold;">对方收款还剩<br></span>
                                                <span style="color:#06b6b0; font-weight: bold;" id="t_duj<?php echo ($k); ?>">00天</span>
                                                <span style="color:#06b6b0; font-weight: bold;" id="t_huj<?php echo ($k); ?>">00时</span>
                                                <span style="color:#06b6b0; font-weight: bold;" id="t_muj<?php echo ($k); ?>">00分</span>
                                                <span style="color:#06b6b0; font-weight: bold;" id="t_suj<?php echo ($k); ?>">00秒</span>
                                        </td>
                                        <td>0%</td>
                                        
                                            <script>
                                               function GetRTime(){
                                                   var EndTime= new Date('<?php echo ($daojiinputuj); ?>');
                                                   var NowTime = new Date();
                                                   var t =EndTime.getTime() - NowTime.getTime();
                                                   var d=Math.floor(t/1000/60/60/24);
                                                   var h=Math.floor(t/1000/60/60%24);
                                                   var m=Math.floor(t/1000/60%60);
                                                   var s=Math.floor(t/1000%60);
                                            
                                                   document.getElementById("t_duj<?php echo ($k); ?>").innerHTML = d + "天";
                                                   document.getElementById("t_huj<?php echo ($k); ?>").innerHTML = h + "时";
                                                   document.getElementById("t_muj<?php echo ($k); ?>").innerHTML = m + "分";
                                                   document.getElementById("t_suj<?php echo ($k); ?>").innerHTML = s + "秒";
                                               }
                                               setInterval(GetRTime,0);
                                            </script><?php endif; ?>


                                        <?php elseif($val_users_invest["uiZhifu"] == 1 AND $val_users_invest["uiSuccess"] == 1): ?>
                                        <td style="color:#16ac79">援助进行中</td>
                                        <td style="color:#16ac79">
                                                <span style="color:#06b6b0; font-weight: bold;" id="t_jxzqsd<?php echo ($k); ?>">00天</span>
                                                <span style="color:#06b6b0; font-weight: bold;" id="t_jxzqsh<?php echo ($k); ?>">00时</span>
                                                <span style="color:#06b6b0; font-weight: bold;" id="t_jxzqsm<?php echo ($k); ?>">00分</span>
                                                <span style="color:#06b6b0; font-weight: bold;" id="t_jxzqss<?php echo ($k); ?>">00秒</span>
                                        </td>
                                                  <script>
                                               function GetRTime(){
                                                   var EndTime= new Date('<?php echo ($daenddateutuj); ?>');
                                                   var NowTime = new Date();
                                                   var t =EndTime.getTime() - NowTime.getTime();
                                                   var d=Math.floor(t/1000/60/60/24);
                                                   var h=Math.floor(t/1000/60/60%24);
                                                   var m=Math.floor(t/1000/60%60);
                                                   var s=Math.floor(t/1000%60);
                                            
                                                   document.getElementById("t_jxzqsd<?php echo ($k); ?>").innerHTML = d + "天";
                                                   document.getElementById("t_jxzqsh<?php echo ($k); ?>").innerHTML = h + "时";
                                                   document.getElementById("t_jxzqsm<?php echo ($k); ?>").innerHTML = m + "分";
                                                   document.getElementById("t_jxzqss<?php echo ($k); ?>").innerHTML = s + "秒";
                                               }
                                               setInterval(GetRTime,0);
                                            </script><?php endif; ?>
                                        
                                            
                                        
                                            
                                        
                                        

                                        </tr><?php endforeach; endif; else: echo "$empty" ;endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title panel panel-warning" >
                                <button type="button" class="btn btn-w-m btn-warning"><a style="color:#ffffff" href="/Assistance/wantuninvest/uId/<?php echo ($uId); ?>">接受援助
                    </a></button>
                                <div class="ibox-tools">
                                   <a style="color:#faa757" href="/Assistance/wantuninvestlists/uId/<?php echo ($uId); ?>">更多</a>
                                </div>
                            </div>
                            <div class="ibox-content">
                                <table class="table table-hover no-margins">
                                    <thead>
                                        <tr>
                                            <th>订单</th>
                                            <!--
                                            <th>日期</th>
                                            -->
                                            <th>金额</th>
                                            <th>交易状态</th>
                                            <th>援助人</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(is_array($rs_users_uninvest)): $k = 0; $__LIST__ = $rs_users_uninvest;if( count($__LIST__)==0 ) : echo "$unempty" ;else: foreach($__LIST__ as $key=>$val_users_uninvest): $mod = ($k % 2 );++$k; $uuniJiuyuanUid=$val_users_uninvest["uuniJiuyuanUid"]; if($uuniJiuyuanUid==0 || $uuniJiuyuanUid==null){ $uuniJiuyuanUid=0; } $users=M("users"); $rs_use=$users->where("uId={$uuniJiuyuanUid}")->field("uUser,uId")->find(); $users_parameters=M("users_parameters"); $rs_xiqian=$users_parameters->where("upId=1")->field("upCollectionPeriod")->find(); $maxyespay=$rs_xiqian["upCollectionPeriod"]*3600; $paytime=strtotime($val_users_uninvest["uuniPayDate"]); $nowtime=time(); $shengyuyespay=$nowtime-($maxyespay+$paytime); if($shengyuyespay>0){ $shengyuyespay=0; } ?>
                                        <tr>
                                        <?php if($val_users_uninvest["uuniState"] == 0): ?><td><span class="label label-default">待匹配</span>
                                        <?php elseif($val_users_uninvest["uuniState"] == 1 AND $val_users_uninvest["uuniPay"] == 0): ?>
                                        	<td><span class="label label-info"><a style="color: #ffffff" href="/Assistance/showuserinfo/uId/<?php echo ($rs_use["uId"]); ?>">待付款</a></span>
                                            
                                            <?php elseif($val_users_uninvest["uuniState"] == 1 AND $val_users_uninvest["uuniPay"] == 1 AND $val_users_uninvest["uuniSuccess"] == 0): ?>

                                            <?php if($shengyuyespay == 0): ?><td><span class="label label-default"><a style="color: #ffffff" >待收款</a></span>
                                            <?php else: ?>
                                            <td><span class="label label-danger"><a style="color: #ffffff" href="/Assistance/yesunpayinvest/uuniId/<?php echo ($val_users_uninvest["uuniId"]); ?>">待收款</a></span><?php endif; endif; ?>
                                            </td>

                                            <td><?php echo ($val_users_uninvest["uuniJiner"]); ?></td>
                                        <?php if($val_users_uninvest["uuniState"] == 0): ?><td style="color:#949492">等待系统匹配</td>
                                        <?php elseif($val_users_uninvest["uuniState"] == 1 AND $val_users_uninvest["uuniPay"] == 0): ?>
                                            <?php $users_parameters=M("users_parameters"); $rsxiqian=$users_parameters->where("upId=1")->field("upTermOfInvestment,upPaymentPeriod,upCollectionPeriod")->find(); $maxpaytimef=($rsxiqian["upPaymentPeriod"])*3600; $nowtimef=time(); $pipeitimef=strtotime($val_users_uninvest["uuniStateDate"]); $enddaojishif=$pipeitimef+$maxpaytimef; $daojiinputf=date("Y/m/d H:i:s",$enddaojishif); ?>
                                            <?php if($enddaojishif < $nowtimef): ?><td>
                                            系统匹配时间<br> <?php echo ($val_users_uninvest["uuniStateDate"]); ?><br>
                                        <span style="color:#e1790a; font-weight: bold;">对方付款超时</span></td>

                                            <?php else: ?>
                                            <td>
                                            系统匹配时间<br><?php echo ($val_users_uninvest["uuniStateDate"]); ?><br>
                                            <span style="color:#06b6b0; font-weight: bold;">对方付款还剩<br></span>
                                                <span style="color:#06b6b0; font-weight: bold;" id="t_duf<?php echo ($k); ?>">00天</span>
                                                <span style="color:#06b6b0; font-weight: bold;" id="t_huf<?php echo ($k); ?>">00时</span>
                                                <span style="color:#06b6b0; font-weight: bold;" id="t_muf<?php echo ($k); ?>">00分</span>
                                                <span style="color:#06b6b0; font-weight: bold;" id="t_suf<?php echo ($k); ?>">00秒</span>
                                            </td>
                                            <script>
                                               function GetRTime(){
                                                   var EndTime= new Date('<?php echo ($daojiinputf); ?>');
                                                   var NowTime = new Date();
                                                   var t =EndTime.getTime() - NowTime.getTime();
                                                   var d=Math.floor(t/1000/60/60/24);
                                                   var h=Math.floor(t/1000/60/60%24);
                                                   var m=Math.floor(t/1000/60%60);
                                                   var s=Math.floor(t/1000%60);
                                            
                                                   document.getElementById("t_duf<?php echo ($k); ?>").innerHTML = d + "天";
                                                   document.getElementById("t_huf<?php echo ($k); ?>").innerHTML = h + "时";
                                                   document.getElementById("t_muf<?php echo ($k); ?>").innerHTML = m + "分";
                                                   document.getElementById("t_suf<?php echo ($k); ?>").innerHTML = s + "秒";
                                               }
                                               setInterval(GetRTime,0);
                                            </script><?php endif; ?>

                                        <?php elseif($val_users_uninvest["uuniPay"] == 1 AND $val_users_uninvest["uuniSuccess"] == 0): ?>
                                        <?php $users_parameters=M("users_parameters"); $rs_xiqian=$users_parameters->where("upId=1")->field("upTermOfInvestment,upPaymentPeriod,upCollectionPeriod")->find(); $maxyespayu=$rs_xiqian["upCollectionPeriod"]*3600; $paytime=strtotime($val_users_uninvest["uuniPayDate"]); $nowtimeu=time(); $enddaojishiu=$paytime+$maxyespayu; $daojiinputu=date("Y/m/d H:i:s",$enddaojishiu); ?>
                                        <?php if($enddaojishiu < $nowtimeu): ?><td>
                                        对方打款时间<br> <?php echo ($val_users_uninvest["uuniPayDate"]); ?><br>
                                        <span style="color:#ff0000; font-weight: bold;">我方收款超时</span>
                                        </td>

                                        <?php else: ?>
                                        <td >
                                                对方打款时间<br> <?php echo ($val_users_uninvest["uuniPayDate"]); ?><br>
                                                <span style="color:#ff0000; font-weight: bold;">我方收款还剩<br></span>
                                                <span style="color:#ff0000; font-weight: bold;" id="t_du<?php echo ($k); ?>">00天</span>
                                                <span style="color:#ff0000; font-weight: bold;" id="t_hu<?php echo ($k); ?>">00时</span>
                                                <span style="color:#ff0000; font-weight: bold;" id="t_mu<?php echo ($k); ?>">00分</span>
                                                <span style="color:#ff0000; font-weight: bold;" id="t_su<?php echo ($k); ?>">00秒</span>
                                        </td>
                                        
                                            <script>
                                               function GetRTime(){
                                                   var EndTime= new Date('<?php echo ($daojiinputu); ?>');
                                                   var NowTime = new Date();
                                                   var t =EndTime.getTime() - NowTime.getTime();
                                                   var d=Math.floor(t/1000/60/60/24);
                                                   var h=Math.floor(t/1000/60/60%24);
                                                   var m=Math.floor(t/1000/60%60);
                                                   var s=Math.floor(t/1000%60);
                                            
                                                   document.getElementById("t_du<?php echo ($k); ?>").innerHTML = d + "天";
                                                   document.getElementById("t_hu<?php echo ($k); ?>").innerHTML = h + "时";
                                                   document.getElementById("t_mu<?php echo ($k); ?>").innerHTML = m + "分";
                                                   document.getElementById("t_su<?php echo ($k); ?>").innerHTML = s + "秒";
                                               }
                                               setInterval(GetRTime,0);
                                            </script><?php endif; ?>

                                        <?php elseif($val_users_uninvest["uuniPay"] == 1 AND $val_users_uninvest["uuniSuccess"] == 1): ?>
                                            <td>本轮援助已结束</td><?php endif; ?>
                                        <?php if($rs_use["uUser"] == ''): ?><td>还未匹配</td>
                                        <?php else: ?>
                                            <td class="text-navy"><?php echo ($rs_use["uUser"]); ?></td><?php endif; ?>
                                        </tr><?php endforeach; endif; else: echo "$unempty" ;endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <script src="/Public/Default/js/jquery.min.js?v=2.1.4"></script>
    <script src="/Public/Default/js/bootstrap.min.js?v=3.3.6"></script>
    <script src="/Public/Default/js/plugins/flot/jquery.flot.js"></script>
    <script src="/Public/Default/js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="/Public/Default/js/plugins/flot/jquery.flot.spline.js"></script>
    <script src="/Public/Default/js/plugins/flot/jquery.flot.resize.js"></script>
    <script src="/Public/Default/js/plugins/flot/jquery.flot.pie.js"></script>
    <script src="/Public/Default/js/plugins/flot/jquery.flot.symbol.js"></script>
    <script src="/Public/Default/js/plugins/peity/jquery.peity.min.js"></script>
    <script src="/Public/Default/js/demo/peity-demo.min.js"></script>
    <script src="/Public/Default/js/content.min.js?v=1.0.0"></script>
    <script src="/Public/Default/js/plugins/jquery-ui/jquery-ui.min.js"></script>
    <script src="/Public/Default/js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
    <script src="/Public/Default/js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="/Public/Default/js/plugins/easypiechart/jquery.easypiechart.js"></script>
    <script src="/Public/Default/js/plugins/sparkline/jquery.sparkline.min.js"></script>
    <script src="/Public/Default/js/demo/sparkline-demo.min.js"></script>
 
</body>

</html>