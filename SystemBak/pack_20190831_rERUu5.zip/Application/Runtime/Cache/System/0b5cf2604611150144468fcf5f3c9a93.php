<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>焦点图列表</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="/Public/Default/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="/Public/Default/css/font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <!-- Data Tables -->
    <link href="/Public/Default/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">

    <link href="/Public/Default/css/animate.min.css" rel="stylesheet">
    <link href="/Public/Default/css/style.min.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>轮播图管理<small><a  style="margin-left:20px;"  href="/System/Zccfset/focusmapadd">添加轮播图</a></small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">

                        <table class="table table-striped table-bordered table-hover dataTables-example">
                            <thead>
                                <tr>
                                    <th>排序</th>
                                    <th>标题</th>
                                    <th>颜色</th>
                                    <th class="dropdown hidden-xs">焦点图</th>
                                    <th >是否显示</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if(is_array($rs_focusmap)): foreach($rs_focusmap as $key=>$val_focusmap): ?><tr>
                                    <td><?php echo ($val_focusmap["zfNum"]); ?></td>
                                    <td><?php echo ($val_focusmap["zfTitle"]); ?></td>
                                    <td><?php echo ($val_focusmap["zfColor"]); ?></td>
                                    <td><img src="/<?php echo ($val_focusmap["zfImages"]); ?>" width="173px" height="80px" alt="<?php echo ($val_focusmap["zfTitle"]); ?>"></td>
                                    
                                    <td>
                                    <?php if($val_focusmap["zfOnOff"] == 1): ?><a href="/System/Zccfset/SetShow/zfId/<?php echo ($val_focusmap["zfId"]); ?>/zfOnOff/0">显示</a>
                                    <?php else: ?>
                                    <a href="/System/Zccfset/SetShow/zfId/<?php echo ($val_focusmap["zfId"]); ?>/zfOnOff/1">隐藏</a><?php endif; ?>
                                    </td>
                                    <td>
                                    <a href="/System/Zccfset/focusmapupdate/zfId/<?php echo ($val_focusmap["zfId"]); ?>">修改</a> | <a href="/System/Zccfset/FocusDel/zfId/<?php echo ($val_focusmap["zfId"]); ?>">删除</a>
                                    </td>
                                </tr><?php endforeach; endif; ?>
                            </tbody>
                            
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="/Public/Default/js/jquery.min.js?v=2.1.4"></script>
    <script src="/Public/Default/js/bootstrap.min.js?v=3.3.6"></script>
    <script src="/Public/Default/js/plugins/jeditable/jquery.jeditable.js"></script>
    <script src="/Public/Default/js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="/Public/Default/js/plugins/dataTables/dataTables.bootstrap.js"></script>
    <script src="/Public/Default/js/content.min.js?v=1.0.0"></script>
    <script>
        $(document).ready(function(){$(".dataTables-example").dataTable();var oTable=$("#editable").dataTable();oTable.$("td").editable("../example_ajax.php",{"callback":function(sValue,y){var aPos=oTable.fnGetPosition(this);oTable.fnUpdate(sValue,aPos[0],aPos[1])},"submitdata":function(value,settings){return{"row_id":this.parentNode.getAttribute("id"),"column":oTable.fnGetPosition(this)[2]}},"width":"90%","height":"100%"})});function fnClickAddRow(){$("#editable").dataTable().fnAddData(["Custom row","New row","New row","New row","New row"])};
    </script>

</body>

</html>