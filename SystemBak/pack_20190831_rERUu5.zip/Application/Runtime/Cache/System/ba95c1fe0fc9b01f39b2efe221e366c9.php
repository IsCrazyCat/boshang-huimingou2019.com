<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改公告</title>
    <link rel="shortcut icon" href="favicon.ico"> <link href="/Public/Default/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="/Public/Default/css/font-awesome.min.css?v=4.4.0" rel="stylesheet">
    <link href="/Public/Default/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="/Public/Default/css/animate.min.css" rel="stylesheet">
    <link href="/Public/Default/css/style.min.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>修改公告 <small><a href="/System/Announcement/lists"> 公告列表</a></small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-wrench"></i>
                            </a>
                            
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
                        <form method="post" action="/System/Announcement/UpdateAction/annId/<?php echo ($rs_announcement["annId"]); ?>" class="form-horizontal" id="form-admin-add" >
                            <div class="form-group">
                                <label class="col-sm-2 control-label">标记</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="annNum" id="annNum" value="<?php echo ($rs_announcement["annNum"]); ?>" placeholder="请输入公告顺序" >
                                </div>
                            </div>
                            
                                <div class="form-group">
                                <label class="col-sm-2 control-label">标题</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="annTitle" id="annTitle" value="<?php echo ($rs_announcement["annTitle"]); ?>" placeholder="控制在30个汉字内" class="form-control">
                                    </div>
                            	</div>
                            
                            
                                <div class="form-group">
                                <label class="col-sm-2 control-label">内容</label>
                                    <div class="col-sm-10">
                                     <!-- 加载编辑器的容器 -->
    <script id="container" name="annContent" type="text/plain"><?php echo ($rs_announcement["annContent"]); ?>
    </script>
    <!-- 配置文件 -->
    <script type="text/javascript" src="/Public/Default/ueditor/ueditor.config.js"></script>
    <!-- 编辑器源码文件 -->
    <script type="text/javascript" src="/Public/Default/ueditor/ueditor.all.js"></script>
    <!-- 实例化编辑器 -->
    <script type="text/javascript">
        var ue = UE.getEditor('container', {
    
    autoHeightEnabled: true,
    autoFloatEnabled: true
});
    </script>
                                       
                                    </div>
                            	</div>
                           
                           
                                
                            <div class="hr-line-dashed"></div>
                            <!--
                            <div class="form-group">
                                <div class="col-sm-4 col-sm-offset-2">
                                    <button class="btn btn-primary" type="submit">修改公告</button>
                                   
                                </div>
                            </div>
                            -->
                            <div class="form-group">
                                <div class="col-sm-4 col-sm-offset-2">
                                    <input class="btn btn-primary" type="submit" value="修改公告">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="/Public/Default/js/jquery.min.js?v=2.1.4"></script>
    <script src="/Public/Default/js/bootstrap.min.js?v=3.3.6"></script>
    <script src="/Public/Default/js/content.min.js?v=1.0.0"></script>
    <script src="/Public/Default/js/plugins/iCheck/icheck.min.js"></script>

<script type="text/javascript" src="/Public/Default/check/js/jquery.validate.min.js"></script> 

<script type="text/javascript" src="/Public/Default/check/js/messages_zh.min.js"></script> 



<script type="text/javascript" src="/Public/Default/check/js/validate-methods.js"></script> 



   
    <script>
        $(document).ready(function(){$(".i-checks").iCheck({checkboxClass:"icheckbox_square-green",radioClass:"iradio_square-green",})});
    </script>
    
    <script type="text/javascript">
	$(function(){
	$("#form-admin-add").validate({
		rules:{
			annNum:{
				required:true,
			},
			annTitle:{
				required:true,
				minlength:5,
				maxlength:30
			},
			annContent:{
				required:true,
                minlength:20,
                maxlength:6000
			}
		},
		onkeyup:false,
		focusCleanup:true,
		success:"valid",
		submitHandler:function(form){
			$(form).ajaxSubmit();
			var index = parent.layer.getFrameIndex(window.name);
			parent.$('.btn-refresh').click();
			parent.layer.close(index);
		}
	});
});
</script> 
    
    
</body>

</html>