<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>排单币审核列表</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="/Public/Default/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="/Public/Default/css/font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <!-- Data Tables -->
    <link href="/Public/Default/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">

    <link href="/Public/Default/css/animate.min.css" rel="stylesheet">
    <link href="/Public/Default/css/style.min.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>排单币审核列表 <small><a href="/System/Users/givecode">发放排单币</a></small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
                        <table class="table table-striped table-bordered table-hover dataTables-example">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>申请账户</th>
                                    <th class="dropdown hidden-xs">申请时间</th>
                                    <th class="dropdown hidden-xs">售价</th>
                                    <th class="dropdown hidden-xs">购买个数</th>
                                    <th class="dropdown hidden-xs">实付金额</th>
                                    <th >审核状态</th>
                                    <th class="dropdown hidden-xs">发放次数</th>
                                    <th class="dropdown hidden-xs">虚假提交次数</th>
                                    <th class="dropdown hidden-xs">支付截图</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if(is_array($rs_apply)): $i = 0; $__LIST__ = $rs_apply;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val_apply): $mod = ($i % 2 );++$i;?><tr class="gradeX">
                                    <td><?php echo ($val_apply["uarId"]); ?></td>
                                    <?php $uId=$val_apply["uarUid"]; $user=M("users"); $rs_user=$user->where("uId={$uId}")->field("uUser")->find(); $userInfo=$rs_user["uUser"]; ?>

                                    <td><a href="/System/Users/reviewcodeone/uarId/<?php echo ($val_apply["uarId"]); ?>"><?php echo ($userInfo); ?></a></td>

                                    <td  class="dropdown hidden-xs"><?php echo ($val_apply["uarDate"]); ?></td>
                                    <td  class="dropdown hidden-xs"><?php echo ($val_apply["uarPrice"]); ?></td>
                                    <td  class="dropdown hidden-xs"><?php echo ($val_apply["uarCodeNum"]); ?></td>
                                    <td  class="dropdown hidden-xs"><?php echo ($val_apply["uarPayPrice"]); ?></td>
                                    <?php if($val_apply["uarState"] == 0): ?><td><button type="button" class="btn btn-success btn-xs" style="margin-top: 5px;">还未审核</button></td>
                                    <?php elseif($val_apply["uarState"] == 1): ?>
                                        <td><button type="button" class="btn btn-primary btn-xs" style="margin-top: 5px;">已经发放</button></td>

                                    <?php elseif($val_apply["uarState"] == 2): ?>
                                        <td><button type="button" class="btn btn-danger btn-outline btn-xs" style="margin-top: 5px;">虚假提交</button></td>

                                    <?php elseif($val_apply["uarState"] == 3): ?>
                                        <td><button type="button" class="btn btn-warning btn-xs" style="margin-top: 5px;">冻结账户</button></td>

                                    <?php elseif($val_apply["uarState"] == 4): ?>
                                        <td><button type="button" class="btn btn-danger btn-xs" style="margin-top: 5px;">已被封号</button></td><?php endif; ?>

                                     <td  class="dropdown hidden-xs"><?php echo ($val_apply["uarCodeNumState"]); ?></td>
                                    <td  class="dropdown hidden-xs"><?php echo ($val_apply["uarErrorNum"]); ?></td>

                                    <?php if($val_apply["uarFiles"] == null): ?><td  class="dropdown hidden-xs"><img src="/Public/Default/img/defaultzhifu.jpg" width="80px;" height="80px;"></td>
                                    <?php else: ?>
                                    <td  class="dropdown hidden-xs"><a href="/System/Users/reviewcodeone/uarId/<?php echo ($val_apply["uarId"]); ?>"><img src="/<?php echo ($val_apply["uarFiles"]); ?>" width="80px;" height="80px;"></td></a><?php endif; ?>
                                    <?php $fafangnum=$val_apply["uarCodeNumState"]; $paynum=$val_apply["uarCodeNum"]; if($fafangnum<$paynum){ $fafangsta=0; }else{ $fafangsta=1; } ?>
                                    <?php if($val_apply["uarState"] != 1): ?><td><a href="/System/Users/paidanbifasong/uarId/<?php echo ($val_apply["uarId"]); ?>">发放</a></td>
                                    <?php else: ?>
                                        <td style="color: #ff0000">操作完成</td><?php endif; ?>
                                </tr><?php endforeach; endif; else: echo "" ;endif; ?>    
                            </tbody>
                            
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="/Public/Default/js/jquery.min.js?v=2.1.4"></script>
    <script src="/Public/Default/js/bootstrap.min.js?v=3.3.6"></script>
    <script src="/Public/Default/js/plugins/jeditable/jquery.jeditable.js"></script>
    <script src="/Public/Default/js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="/Public/Default/js/plugins/dataTables/dataTables.bootstrap.js"></script>
    <script src="/Public/Default/js/content.min.js?v=1.0.0"></script>
    <script>
        $(document).ready(function(){$(".dataTables-example").dataTable();var oTable=$("#editable").dataTable();oTable.$("td").editable("../example_ajax.php",{"callback":function(sValue,y){var aPos=oTable.fnGetPosition(this);oTable.fnUpdate(sValue,aPos[0],aPos[1])},"submitdata":function(value,settings){return{"row_id":this.parentNode.getAttribute("id"),"column":oTable.fnGetPosition(this)[2]}},"width":"90%","height":"100%"})});function fnClickAddRow(){$("#editable").dataTable().fnAddData(["Custom row","New row","New row","New row","New row"])};
    </script>

</body>

</html>