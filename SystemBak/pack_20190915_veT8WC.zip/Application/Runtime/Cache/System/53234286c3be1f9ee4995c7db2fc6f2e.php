<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>提供援助列表</title>

    <link rel="shortcut icon" href="favicon.ico"> <link href="/Public/Default/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="/Public/Default/css/font-awesome.min.css?v=4.4.0" rel="stylesheet">

    <!-- Data Tables -->
    <link href="/Public/Default/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">

    <link href="/Public/Default/css/animate.min.css" rel="stylesheet">
    <link href="/Public/Default/css/style.min.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>提供援助列表 <small></small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
                        <table class="table table-striped table-bordered table-hover dataTables-example">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>援助账户</th>
                                    <th class="dropdown hidden-xs">手机</th>
                                    <th class="dropdown hidden-xs">支付账户</th>
                                    <th>援助金额</th>
                                    <th class="dropdown hidden-xs">被援助账户</th>
                                    <th class="dropdown hidden-xs">被援助人手机</th>
                                    <th class="dropdown hidden-xs">收款账户</th>
                                    <th class="dropdown hidden-xs">匹配时间</th>
                                    <th class="dropdown hidden-xs">打款时间/还剩余</th>
                                    <th>凭证</th>
                                    <th class="dropdown hidden-xs">状态</th>
                                    <th><span class="dropdown hidden-xs">援助</span>完成度</th>

                                </tr>
                            </thead>
                            <tbody>
                            <?php if(is_array($rs_invest)): $i = 0; $__LIST__ = $rs_invest;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val_invest): $mod = ($i % 2 );++$i; $uId=$val_invest["uiUid"]; $uuniId=$val_invest["uiBeijiuyuanUid"]; $users=M("users"); $rs_users=$users->where("uId={$uId}")->field("uId,uName,uTel,uUser,uZhifubao,uLock")->find(); $rs_uunsers=$users->where("uId={$uuniId}")->field("uId,uName,uTel,uUser,uZhifubao")->find(); ?>
                                
                                <?php $users_parameters=M("users_parameters"); $fukuanqx=$users_parameters->where("upId=1")->field("upPaymentPeriod")->find(); $start=strtotime(($val_invest["uiStateDate"])); $stepend=$fukuanqx["upPaymentPeriod"]*3600; $nowtime=strtotime(date("Y-m-d H:i:s")); $shengyu=round(((($start+$stepend)-$nowtime)/3600),1); if($shengyu<1){ $fenzhong=floor((($start+$stepend)-$nowtime)/60); } ?>

                                <?php $uunistatedate=$val_invest["uiStateDate"]; $users_uninvest=M("users_uninvest"); $rs_users_uninvest=$users_uninvest->where("uuniStateDate='{$uunistatedate}'")->field("uuniId")->find(); $uuniId=$rs_users_uninvest["uuniId"]; ?>
                                <tr class="gradeX">
                                    <td><?php echo ($val_invest["uiId"]); ?></td>
                                    <td><?php echo ($rs_users["uUser"]); ?></td>
                                    <td class="dropdown hidden-xs"><?php echo ($rs_users["uTel"]); ?></td>
                                    <td class="dropdown hidden-xs"><a href="/System/Assistance/pingzheng/uiId/<?php echo ($val_invest["uiId"]); ?>"><?php echo ($rs_users["uZhifubao"]); ?></a></td>
                                    <td ><?php echo ($val_invest["uiUJiner"]); ?></td>
                                    <td class="dropdown hidden-xs"><?php echo ($rs_uunsers["uUser"]); ?></td>
                                    <td class="dropdown hidden-xs"><?php echo ($rs_uunsers["uTel"]); ?></td>
                                    <td class="dropdown hidden-xs"><a href="/System/Assistance/pingzheng/uiId/<?php echo ($val_invest["uiId"]); ?>"><?php echo ($rs_uunsers["uZhifubao"]); ?></a></td>
                                    <td class="dropdown hidden-xs"><?php echo ($val_invest["uiStateDate"]); ?></td>

                                    <?php if($val_invest["uiZhifu"] == 0): if($shengyu > 1): ?><td class="dropdown hidden-xs">还剩余 <?php echo ($shengyu); ?> 小时</td>
                                        <?php elseif($shengyu == 1): ?>
                                        <td class="dropdown hidden-xs">还剩余 <?php echo ($shengyu); ?> 小时</td>
                                        <?php elseif($shengyu < 1): ?>
                                            <?php if($fenzhong > 0): ?><td class="dropdown hidden-xs">还剩余 <?php echo ($fenzhong); ?> 分钟</td>
                                            <?php else: ?>
                                                <td class="dropdown hidden-xs"><a href="/System/Assistance/SetNoPipei/uiId/<?php echo ($val_invest["uiId"]); ?>/uuniId/<?php echo ($uuniId); ?>">取消匹配</a></td><?php endif; endif; ?>

                                    <?php else: ?>

                                        <td class="dropdown hidden-xs"><?php echo ($val_invest["uiZhifuDate"]); ?></td><?php endif; ?>
                                    <td><a href="/System/Assistance/pingzheng/uiId/<?php echo ($val_invest["uiId"]); ?>">查看</a></td>
                                    
                                    <?php if($val_invest["uiZhifu"] == 0): if($fenzhong < 0 AND $shengyu < 1): ?><td><a class="btn btn-danger btn-rounded btn-outline btn-xs">打款超时</a> 
                                            <?php if($rs_users["uLock"] == 1): ?><a class="btn btn-danger btn-rounded btn-xs" href="/System/Assistance/SetDongjie/uId/<?php echo ($rs_users["uId"]); ?>">冻结账户</a>
                                            <?php else: ?>
                                             <a class="btn btn-default btn-rounded btn-xs">冻结账户</a><?php endif; ?>
                                            </td>
                                            <td>0%</td>
                                        <?php else: ?>
                                            <td class="dropdown hidden-xs"><a class="btn btn-danger btn-rounded btn-xs">等待援助人付款</a></td>
                                            <td>0%</td><?php endif; ?>
                                    <?php elseif($val_invest["uiZhifu"] == 1 AND $val_invest["uiSuccess"] == 0): ?>
                                    <td class="dropdown hidden-xs"><a class="btn btn-warning btn-rounded btn-xs">等待被援助人收款</a></td>
                                    <td>0%</td>
                                    <?php elseif($val_invest["uiZhifu"] == 1 AND $val_invest["uiSuccess"] == 1 AND $val_invest["uiTouziEnd"] == 0): ?>
                                    <?php $nowtime=time(); $enddate=strtotime($val_invest["uiTouziEndDate"]); $startqixian=strtotime($val_invest["uiSuccessDate"]); $qixian=$enddate-$startqixian; $wanchengdu=round((($nowtime-$startqixian)/$qixian),2)*100; if($wanchengdu>100){ $wanchengdu=100; }elseif($wanchengdu<0){ $wanchengdu=0; } ?>
                                    <?php if($wanchengdu == 100): ?><td class="dropdown hidden-xs"><a class="btn btn-success btn-rounded btn-xs">本轮援助已到期</a></td>

                                    <?php else: ?>
                                    <td class="dropdown hidden-xs"><a class="btn btn-info btn-rounded btn-xs">正在援助之中</a></td><?php endif; ?>
                                    <td><?php echo ($wanchengdu); ?> %</td>
                                    <?php elseif($val_invest["uiZhifu"] == 1 AND $val_invest["uiSuccess"] == 1 AND $val_invest["uiTouziEnd"] == 1 ): ?>
                                    <td class="dropdown hidden-xs"><a class="btn btn-primary btn-rounded btn-xs">本轮援助已到期</a></td>
                                    <td>100%</td><?php endif; ?>
                                </tr><?php endforeach; endif; else: echo "" ;endif; ?>    
                            </tbody>
                            
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="/Public/Default/js/jquery.min.js?v=2.1.4"></script>
    <script src="/Public/Default/js/bootstrap.min.js?v=3.3.6"></script>
    <script src="/Public/Default/js/plugins/jeditable/jquery.jeditable.js"></script>
    <script src="/Public/Default/js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="/Public/Default/js/plugins/dataTables/dataTables.bootstrap.js"></script>
    <script src="/Public/Default/js/content.min.js?v=1.0.0"></script>
    <script>
        $(document).ready(function(){$(".dataTables-example").dataTable();var oTable=$("#editable").dataTable();oTable.$("td").editable("../example_ajax.php",{"callback":function(sValue,y){var aPos=oTable.fnGetPosition(this);oTable.fnUpdate(sValue,aPos[0],aPos[1])},"submitdata":function(value,settings){return{"row_id":this.parentNode.getAttribute("id"),"column":oTable.fnGetPosition(this)[2]}},"width":"90%","height":"100%"})});function fnClickAddRow(){$("#editable").dataTable().fnAddData(["Custom row","New row","New row","New row","New row"])};
    </script>

</body>

</html>